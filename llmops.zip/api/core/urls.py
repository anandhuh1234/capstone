from django.urls import path
from . import views

urlpatterns = [
    path('login', views.login, name='login'),
    path('signup', views.signup, name='signup'),
    path('list_users', views.list_users, name='list_users'),
    path('update_user_role', views.update_user_role, name='update_user_role'),
    path('benchmark_evaluation', views.benchmark_evaluation, name='benchmark_evaluation'),
    path('list_benchmark_data', views.list_benchmark_data, name='list_benchmark_data'),
    path('list_models', views.list_models, name='list_models'),
    path('add_model', views.add_model, name='add_model'),
    path('remove_model', views.remove_model, name='remove_model'),
    path('delete_all_entries', views.delete_all_entries, name='delete_all_entries'),
]