import os
import json
import requests
from dotenv import load_dotenv
load_dotenv()

BASE_URL = os.getenv("BASE_URL")

def login(email, password):
    ENDPOINT = '/login'
    URL = BASE_URL + ENDPOINT
    payload = {
        "email": email,
        "password":password,
    }
    response = requests.post(url=URL, json=payload)
    data = response.json()
    return data

def signup(name, email, password):
    ENDPOINT = '/signup'
    URL = BASE_URL + ENDPOINT
    payload = {
        "name": name, 
        "email": email,
        "password":password,
    }
    response = requests.post(url=URL, json=payload)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data

def list_models():
    ENDPOINT = '/list_models'
    URL = BASE_URL + ENDPOINT
    response = requests.get(url=URL)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data

def list_benchmark_data():
    ENDPOINT = '/list_benchmark_data'
    URL = BASE_URL + ENDPOINT
    response = requests.get(url=URL)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data

def benchmark_evaluation(model_id, dataset, n_shot, source, subject, mail_alert, token):
    ENDPOINT = '/benchmark_evaluation'
    URL = BASE_URL + ENDPOINT
    payload = {
        "model_id": model_id, 
        "dataset": dataset,
        "n_shot":n_shot,
        "source": source,
        "subject": subject, 
        "mail_alert": mail_alert,
        "token": token
    }
    response = requests.post(url=URL, json=payload)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data

def add_model(model_id, source):
    ENDPOINT = '/add_model'
    URL = BASE_URL + ENDPOINT
    payload = {
        "model_id": model_id,
        "source":source,
    }
    response = requests.post(url=URL, json=payload)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data

def remove_model(model_id, source):
    ENDPOINT = '/remove_model'
    URL = BASE_URL + ENDPOINT
    payload = {
        "model_id": model_id,
        "source":source,
    }
    response = requests.post(url=URL, json=payload)
    if response.status_code==200:
        data = response.json()
    else:
        data = {}
    return data
