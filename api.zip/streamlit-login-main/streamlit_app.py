import streamlit as st
from time import sleep
from navigation import make_sidebar
from utils.api_handler import login
make_sidebar()

col1, col2, col3 = st.columns([0.25, 0.5, 0.25])
col2.markdown("""
        <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
                -webkit-background-clip: text;
                color: transparent;
                font-size: 3em;
                font-weight: bold;">
            LLM Playground
        </h1>
        """, unsafe_allow_html=True)

col2.caption("Please log in to continue")
username = col2.text_input("Email")
password = col2.text_input("Password", type="password")

if col2.button("Log in", type="primary"):
    data = login(username, password)
    if data['status']:
        st.session_state.logged_in = True
        st.session_state.user_role = data['user_role']
        col2.success("Logged in successfully!")
        sleep(1)
        st.switch_page("pages/inference.py")
    else:
        st.error(data['message'])
