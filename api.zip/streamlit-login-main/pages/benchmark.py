from navigation import make_sidebar
make_sidebar()

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st
from datetime import datetime
from utils.api_handler import benchmark_evaluation, list_benchmark_data

subject_mapping = {
    "ARC": ['arc', 'None'],
    "MMLU (All)": ["mmlu", "all"],
    "MMLU (Abstract Algebra)": ["mmlu", "abstract_algebra"],
    "MMLU (Anatomy)": ["mmlu", "anatomy"],
    "MMLU (Astronomy)": ["mmlu", "astronomy"],
    "MMLU (Business Ethics)": ["mmlu", "business_ethics"],
    "MMLU (Clinical Knowledge)": ["mmlu", "clinical_knowledge"],
    "MMLU (College Biology)": ["mmlu", "college_biology"],
    "MMLU (College Chemistry)": ["mmlu", "college_chemistry"],
    "MMLU (College Computer Science)": ["mmlu", "college_computer_science"],
    "MMLU (College Mathematics)": ["mmlu", "college_mathematics"],
    "MMLU (College Medicine)": ["mmlu", "college_medicine"],
    "MMLU (College Physics)": ["mmlu", "college_physics"],
    "MMLU (Computer Security)": ["mmlu", "computer_security"],
    "MMLU (Conceptual Physics)": ["mmlu", "conceptual_physics"],
    "MMLU (Econometrics)": ["mmlu", "econometrics"],
    "MMLU (Electrical Engineering)": ["mmlu", "electrical_engineering"],
    "MMLU (Elementary Mathematics)": ["mmlu", "elementary_mathematics"],
    "MMLU (Formal Logic)": ["mmlu", "formal_logic"],
    "MMLU (Global Facts)": ["mmlu", "global_facts"],
    "MMLU (High School Biology)": ["mmlu", "high_school_biology"],
    "MMLU (High School Chemistry)": ["mmlu", "high_school_chemistry"],
    "MMLU (High School Computer Science)": ["mmlu", "high_school_computer_science"],
    "MMLU (High School European History)": ["mmlu", "high_school_european_history"],
    "MMLU (High School Geography)": ["mmlu", "high_school_geography"],
    "MMLU (High School Government and Politics)": ["mmlu", "high_school_government_and_politics"],
    "MMLU (High School Macroeconomics)": ["mmlu", "high_school_macroeconomics"],
    "MMLU (High School Mathematics)": ["mmlu", "high_school_mathematics"],
    "MMLU (High School Microeconomics)": ["mmlu", "high_school_microeconomics"],
    "MMLU (High School Physics)": ["mmlu", "high_school_physics"],
    "MMLU (High School Psychology)": ["mmlu", "high_school_psychology"],
    "MMLU (High School Statistics)": ["mmlu", "high_school_statistics"],
    "MMLU (High School US History)": ["mmlu", "high_school_us_history"],
    "MMLU (High School World History)": ["mmlu", "high_school_world_history"],
    "MMLU (Human Aging)": ["mmlu", "human_aging"],
    "MMLU (Human Sexuality)": ["mmlu", "human_sexuality"],
    "MMLU (International Law)": ["mmlu", "international_law"],
    "MMLU (Jurisprudence)": ["mmlu", "jurisprudence"],
    "MMLU (Logical Fallacies)": ["mmlu", "logical_fallacies"],
    "MMLU (Machine Learning)": ["mmlu", "machine_learning"],
    "MMLU (Management)": ["mmlu", "management"],
    "MMLU (Marketing)": ["mmlu", "marketing"],
    "MMLU (Medical Genetics)": ["mmlu", "medical_genetics"],
    "MMLU (Miscellaneous)": ["mmlu", "miscellaneous"],
    "MMLU (Moral Disputes)": ["mmlu", "moral_disputes"],
    "MMLU (Moral Scenarios)": ["mmlu", "moral_scenarios"],
    "MMLU (Nutrition)": ["mmlu", "nutrition"],
    "MMLU (Philosophy)": ["mmlu", "philosophy"],
    "MMLU (Prehistory)": ["mmlu", "prehistory"],
    "MMLU (Professional Accounting)": ["mmlu", "professional_accounting"],
    "MMLU (Professional Law)": ["mmlu", "professional_law"],
    "MMLU (Professional Medicine)": ["mmlu", "professional_medicine"],
    "MMLU (Professional Psychology)": ["mmlu", "professional_psychology"],
    "MMLU (Public Relations)": ["mmlu", "public_relations"],
    "MMLU (Security Studies)": ["mmlu", "security_studies"],
    "MMLU (Sociology)": ["mmlu", "sociology"],
    "MMLU (US Foreign Policy)": ["mmlu", "us_foreign_policy"],
    "MMLU (Virology)": ["mmlu", "virology"],
    "MMLU (World Religions)": ["mmlu", "world_religions"]
}

# Page Layout
# st.title("Benchmark Evaluation")
st.markdown("""
    <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
            -webkit-background-clip: text;
            color: transparent;
            font-size: 3em;
            font-weight: bold;">
        Benchmark Evaluation
    </h1>
    """, unsafe_allow_html=True)

# Create two tabs: "Analytics Dashboard" and "Run Evaluation"
tab1, tab2 = st.tabs(["Analytics Dashboard", "Run Evaluation"])

# Tab 1: Analytics Dashboard for displaying historical benchmarks
with tab1:
    st.header("Historical Benchmarks")

    data = list_benchmark_data()
    if data.get('status', False):
        df = pd.DataFrame(data['benchmarks_list'])
        df["initiated_at"] = pd.to_datetime(df["initiated_at"]).dt.strftime("%Y-%m-%d %H:%M:%S")
        df["completed_at"] = pd.to_datetime(df["completed_at"]).dt.strftime("%Y-%m-%d %H:%M:%S")
        
        # Display the historical data in a table format
        st.dataframe(df[["model_id", "dataset", "n_shot", "source", "initiated_at", "status", "completed_at", "score"]],
                     use_container_width=True)
    else:
        st.info("No historical benchmark data available.")

    st.write("")
    st.subheader("Best Score Achieved by Selected Model on Selected Dataset")
    col1, col2 = st.columns(2)
    # Dropdown for selecting dataset
    unique_datasets = df['dataset'].unique()
    selected_dataset = col1.selectbox("Select Dataset", unique_datasets)

    # Filter DataFrame based on selected dataset and model
    filtered_df = df[(df['dataset'] == selected_dataset)]

    # Data Preparation: Get the highest score for each model
    
    if not filtered_df.empty:
        best_score = filtered_df['score'].max()
        st.write(f"The best score achieved on {selected_dataset} is: {best_score}")

        # Plotting: Only if multiple entries exist for the selected model
        if len(filtered_df) > 1:
            best_scores_per_model = filtered_df.groupby("model_id")["score"].max()
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.barplot(x=best_scores_per_model.index, y=best_scores_per_model.values, palette="viridis", ax=ax)
            ax.set_title(f"Best Score Achieved on {selected_dataset}")
            ax.set_xlabel("Model ID")
            ax.set_ylabel("Best Score")
            plt.xticks(rotation=45, ha='right')
            st.pyplot(fig)
        else:
            st.info(f"Only one benchmark result found for {selected_model} on {selected_dataset}. No chart available.")
    else:
        st.info("No benchmark data available for the selected dataset and model.")
# Tab 2: Run Evaluation for initiating a new benchmark task
with tab2:
    st.header("Run a New Benchmark")

    # Input fields for the benchmark_evaluation function
    model_id = st.text_input("Model ID :red[*]", placeholder="Eg: meta-llama/Llama-3.1-8B or llama3.1:8b-instruct-fp16")
    benchmark = st.selectbox('Select benchmark :red[*]', options=list(subject_mapping.keys()))
    n_shot = st.number_input("N-shot :red[*]", min_value=0, max_value=25, value=0, step=5)
    source = st.selectbox('Select model source :red[*]', options=["huggingface", "ollama"])
    mail_alert = st.checkbox("Email me when done", False)
    dataset, subject = subject_mapping[benchmark]
    # Button to initiate a new benchmark task
    if st.button("Run Benchmark"):
        if model_id and benchmark and n_shot and source:
            
            # Prepare the payload for the API
            payload = {
                "model_id": model_id,
                "dataset": dataset,
                "n_shot": n_shot,
                "source": source,
                "subject": subject,
                "mail_alert": mail_alert
            }
            
            # Send the request to initiate benchmarking
            data = benchmark_evaluation(**payload)
            
            if data.get('status', False):
                st.success("Benchmark added to the queue.")
            else:
                st.error(data['message'])
        else:
            st.warning("Please select required fields")