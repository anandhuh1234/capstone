from navigation import make_sidebar
make_sidebar()

import streamlit as st
import pandas as pd
from utils.api_handler import list_models, add_model, remove_model

if "user_role" not in st.session_state:
    st.session_state.user_role = "user"  # Example, change to "admin" as needed

# st.title("Model Configuration")
st.markdown("""
    <h1 style="background: linear-gradient(to right, #E5D74A 21%, #E58643 78%);
            -webkit-background-clip: text;
            color: transparent;
            font-size: 3em;
            font-weight: bold;">
        Model Configuration
    </h1>
    """, unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs(["Available Models", "Add Model", "Remove Model", 'User List'])

# Tab 1: Available Models
with tab1:
    st.subheader("Available Models on Server")

    # Fetch and display available models
    models_data = list_models()
    if models_data.get("status", False):
        models_list = models_data["models_list"]
        
        # Convert models data to DataFrame for display
        df = pd.DataFrame(models_list)
        
        # Display the models in a table format
        st.dataframe(df[["model_id", "source", "status"]])
    else:
        st.error("Failed to fetch models list from the server.")

# Tab 2: Add Model
with tab2:
    st.subheader("Add a New Model")

    # Check if user has admin/superadmin role
    if "admin" in st.session_state.user_role:
        # Input fields for adding a model
        new_model_id = st.text_input("Model ID", placeholder="Enter Model ID, e.g., meta-llama/Llama-3.1-8B")
        new_model_source = st.selectbox("Source", ["huggingface", "ollama"])

        # Button to add the model
        if st.button("Add Model"):
            # Call the add_model function with the required parameters
            response = add_model(model_id=new_model_id, source=new_model_source)
            
            # Display success or error message based on response
            if response.get("status", False):
                st.success(f"Model '{new_model_id}' added successfully.")
            else:
                st.error(f"Failed to add model '{new_model_id}'.")
    else:
        st.warning("You do not have permission to add models. Please contact an administrator.")

# Tab 3: Remove Model
with tab3:
    st.subheader("Remove an Existing Model")

    # Check if user has admin/superadmin role
    if "admin" in st.session_state.user_role:
        models_data = list_models()
        if models_data.get("status", False):
            models_list = models_data["models_list"]

            model_options = [f"{model['model_id']} ({model['source']})" for model in models_list]
            selected_model = st.selectbox("Select Model to Remove", model_options)

            # Extract model_id and source from the selected option
            if selected_model:
                model_id_to_remove, source_to_remove = selected_model.split(" (")
                source_to_remove = source_to_remove.rstrip(")")

                # Button to remove the model
                if st.button("Remove Model"):
                    response = remove_model(model_id=model_id_to_remove, source=source_to_remove)
                    
                    if response.get("status", False):
                        st.success(f"Model '{model_id_to_remove}' removed successfully.")
                    else:
                        st.error(f"Failed to remove model '{model_id_to_remove}'.")
        else:
            st.info("No models available for removal.")
    else:
        st.warning("You do not have permission to remove models. Please contact an administrator.")
