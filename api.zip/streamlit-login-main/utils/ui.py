import streamlit as st

def add_logo():
    # Inject custom CSS to set the width of the sidebar
    st.markdown(
        """
        <style>
            section[data-testid="stSidebar"] {
                width: 250px !important; # Set the width to your desired value
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        <style>
            [data-testid="stSidebarNav"] {
                background-image: url(https://i.imgur.com/ldghDGN.png);
                background-repeat: no-repeat;
                padding-top: 15px;
                background-position: 20px 30px;
                background-size: 180px 50px;
                
            }
    
        </style>
        """
       ,
        unsafe_allow_html=True,
    )
