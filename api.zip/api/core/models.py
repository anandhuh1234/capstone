# # Create your models here.
# from django.db import models
# from django.contrib.auth.models import User

# class UserDetails(models.Model):
#     name = models.CharField(max_length=100)
#     email = models.EmailField(unique=True)
#     organization = models.CharField(max_length=100, blank=True, null=True)
#     password = models.CharField(max_length=255) 
#     token = models.CharField(max_length=255, blank=True, null=True)

#     def __str__(self):
#         return f"{self.name} ({self.email})"

# class Models(models.Model):
#     STATUS_CHOICES = [
#         ('pending', 'Pending'),
#         ('downloading', 'Downloading'),
#         ('completed', 'Completed'),
#         ('failed', 'Failed'),
#     ]
#     model_id = models.CharField(max_length=255)
#     model_name = models.CharField(max_length=255)
#     source = models.CharField(max_length=255, blank=True, null=True)
#     status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
#     downloaded_at = models.DateTimeField(null=True, blank=True)
#     created_by = models.ForeignKey(UserDetails, on_delete=models.SET_NULL, null=True)
#     updated_at = models.DateTimeField(auto_now=True)

#     def __str__(self):
#         return self.model_name

# class Benchmark(models.Model):
#     STATUS_CHOICES = [
#         ('pending', 'Pending'),
#         ('running', 'Running'),
#         ('completed', 'Completed'),
#         ('failed', 'Failed'),
#     ]

#     model = models.ForeignKey(Models, on_delete=models.CASCADE)
#     dataset = models.TextField(blank=True, null=True)
#     n_shot = models.IntegerField()
#     status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
#     results = models.TextField(blank=True, null=True)
#     initiated_by = models.ForeignKey(UserDetails, on_delete=models.SET_NULL, null=True)
#     initiated_at = models.DateTimeField(auto_now_add=True)
#     completed_at = models.DateTimeField(null=True, blank=True)

#     def __str__(self):
#         return f"Benchmark {self.id} - Model: {self.model} - Dataset: {self.dataset}"

