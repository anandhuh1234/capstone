from django.urls import path
from .views import *

urlpatterns = [
    path("ask", ask, name="ask"),
    path("generate_token",generate_token,name="generate_token")
]