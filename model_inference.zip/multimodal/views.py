import os
import json
from django.http import StreamingHttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt
from ollama import Client
import secrets

client = Client(host="http://34.133.154.123:8000")
secret_key = "multimodal"

def _ask(user_input):
    try:
        response = client.chat(
            model="llama3.1:70b-instruct-q4_0", 
            messages=[{"role": "user", "content": user_input}],
            stream=True
            )
        # for chunk in response:
        #     print(chunk["message"]["content"], end="")

        # Yield each chunk of the response for streaming
        for chunk in response:
            yield f"data: {chunk['message']['content']}\n\n"

    except Exception as e:
        yield f"Error in processing request: {str(e)}"

@csrf_exempt
def ask(request):
    if request.method == "POST":
        token = request.headers.get("Authorization")
        user_input = request.POST.get("user_input", "")  # Text input

        print("Question:", user_input)

        with open("credentials.json", "r") as f:
            data = json.load(f)

            if token in data["token_list"]:
                # Streaming the model"s response
                response = StreamingHttpResponse(_ask(user_input), content_type="text/event-stream")
                response["Cache-Control"] = "no-cache"
                response["Access-Control-Allow-Origin"] = "*"
                response["X-Accel-Buffering"] = "no"
                return response
            else:
                return StreamingHttpResponse("Authencation Failed", content_type="text/plain")
    else:
        return StreamingHttpResponse("Invalid request method", content_type="text/plain")

@csrf_exempt
def generate_token(request):
    try:
        token = secrets.token_urlsafe(32)
        token = f"Bearer {token}"

        if not os.path.exists("credentials.json"):
            with open("credentials.json", "w") as f:
                data = {"token_list": []}
                json.dump(data, f, indent=4)

        # Read the current data, update it, and save it back to the file
        with open("credentials.json", "r+") as f:
            data = json.load(f)
            data["token_list"].append(token)
            f.seek(0)
            json.dump(data, f, indent=4)
            f.truncate()

        return JsonResponse({"status": True, "message": "success", "Authorization": token})
    except Exception as e:
        return JsonResponse({"status": False, "message": f"Error: {e}"})